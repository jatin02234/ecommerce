import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nexon',
  templateUrl: './nexon.component.html',
  styleUrls: ['./nexon.component.scss']
})
export class NexonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
