import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-i10',
  templateUrl: './i10.component.html',
  styleUrls: ['./i10.component.scss']
})
export class I10Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
