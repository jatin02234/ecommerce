import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-harrier',
  templateUrl: './harrier.component.html',
  styleUrls: ['./harrier.component.scss']
})
export class HarrierComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
