import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-creta',
  templateUrl: './creta.component.html',
  styleUrls: ['./creta.component.scss']
})
export class CretaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
