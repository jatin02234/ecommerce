import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-brezza',
  templateUrl: './brezza.component.html',
  styleUrls: ['./brezza.component.scss']
})
export class BrezzaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
