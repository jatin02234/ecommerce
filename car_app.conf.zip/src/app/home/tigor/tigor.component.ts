import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tigor',
  templateUrl: './tigor.component.html',
  styleUrls: ['./tigor.component.scss']
})
export class TigorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
