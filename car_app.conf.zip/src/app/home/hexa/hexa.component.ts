import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hexa',
  templateUrl: './hexa.component.html',
  styleUrls: ['./hexa.component.scss']
})
export class HexaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
